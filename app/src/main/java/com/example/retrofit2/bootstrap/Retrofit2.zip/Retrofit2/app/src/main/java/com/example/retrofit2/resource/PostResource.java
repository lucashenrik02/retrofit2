package com.example.retrofit2.resource;

public interface PostResource {
}
